const fs = require('fs');
fetch("https://ibb.co.com/k6GGcJP5").then(r=>r.text()).then(t => {
  const matches = t.match(/https:\/\/i\.[^"]+\.(png|jpg|jpeg|webp)/g);
  if (matches) console.log(matches.join('\n'));
});
