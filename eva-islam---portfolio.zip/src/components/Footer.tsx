export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="py-8 px-4 border-t border-white/5 bg-brand-black text-center relative z-10">
      <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <a href="#home" className="text-xl font-display font-bold track-tight flex items-center gap-2">
            Eva<span className="text-brand-orange">.</span>
        </a>
        <p className="text-xs font-mono text-text-muted">
          &copy; {year} Eva Islam. All rights reserved. Designed for the Future.
        </p>
        <div className="flex gap-4 text-xs font-mono text-text-muted">
           <a href="#" className="hover:text-brand-orange transition-colors">Privacy</a>
           <a href="#" className="hover:text-brand-orange transition-colors">Terms</a>
        </div>
      </div>
    </footer>
  );
}
