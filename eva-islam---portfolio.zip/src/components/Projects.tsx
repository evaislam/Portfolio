import { motion } from 'motion/react';
import { ArrowUpRight, Github, Check } from 'lucide-react';

const PROJECTS = [
  {
    id: 1,
    title: "Sales Performance Analytics Dashboard",
    category: "Data Analytics",
    description: "Designed and deployed a comprehensive sales analytics dashboard to provide real-time visibility into business performance and operational KPIs. The solution centralized reporting processes and enabled stakeholders to make faster, data-driven decisions.\n\nKey Contributions:\n• Built interactive dashboards using business intelligence tools for real-time sales monitoring.\n• Automated reporting workflows, reducing manual reporting efforts by 70%.\n• Developed executive-level KPI scorecards to support monthly performance reviews.\n• Improved reporting efficiency and accelerated decision-making across departments.",
    impact: "70% reduction in manual reporting effort. 25% faster executive decision-making. Enhanced visibility into sales performance and operational metrics.",
    tech: ["Power BI", "SQL Server", "Python", "REST APIs"],
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "Sales KPI & Workflow Automation System",
    category: "Workflow Automation",
    description: "Designed and implemented automated KPI tracking and project management workflows to eliminate repetitive manual processes and improve data accuracy across teams.\n\nKey Contributions:\n• Automated end-to-end sales KPI tracking within Metabase.\n• Developed SQL-based reporting pipelines for performance monitoring.\n• Created workflow automation solutions using SQL and Google Apps Script.\n• Streamlined project tracking and reduced dependency on manual data entry.",
    impact: "Reduced KPI reporting overhead by 90%. Achieved 100% reporting accuracy. Saved approximately 10 hours per week through workflow automation. Increased team productivity and reporting reliability.",
    tech: ["Metabase", "SQL", "Google Apps Script"],
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop"
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-24 px-4 md:px-8 relative bg-brand-dark overflow-hidden">
      <div className="max-w-[1440px] mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
           <motion.div
             initial={{ opacity: 0, y: 30 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true, margin: "-100px" }}
             transition={{ duration: 0.8 }}
           >
            <p className="text-brand-orange uppercase tracking-widest text-sm font-semibold mb-3">04 // Featured Work</p>
            <h2 className="text-4xl md:text-5xl lg:text-7xl font-display font-bold tracking-tight">
              Projects.
            </h2>
           </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          
          {PROJECTS.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.2 }}
              className="p-6 md:p-8 rounded-3xl transition-all duration-500 border bg-white/5 border-white/5 hover:border-white/20 hover:bg-white-[0.07] h-full flex flex-col"
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <p className="text-brand-orange uppercase font-mono text-sm tracking-wider mb-2">{project.category}</p>
                  <h3 className="text-2xl font-display font-bold text-white mb-4">
                    {project.title}
                  </h3>
                </div>
                <span className="text-5xl font-display font-bold text-white/5 blur-[1px]">0{project.id}</span>
              </div>
              
              <div className="mb-6 text-sm md:text-base leading-relaxed space-y-3 flex-grow">
                {project.description.split('\n').map((line, i) => {
                  const trimmed = line.trim();
                  if (trimmed.startsWith('•')) {
                    return (
                      <div key={i} className="flex items-start gap-2">
                        <Check className="text-brand-orange shrink-0 mt-1" size={16} strokeWidth={3} />
                        <span className="text-gray-300">{trimmed.substring(1).trim()}</span>
                      </div>
                    );
                  }
                  if (!trimmed) return null;
                  return (
                    <p key={i} className="text-gray-200 font-medium">
                      {trimmed}
                    </p>
                  );
                })}
              </div>
              <div className="mt-auto">
                <div className="mb-6 p-4 bg-brand-black/50 rounded-xl border border-white/5">
                  <p className="text-sm font-medium text-white mb-2">Business Impact:</p>
                  <p className="text-sm text-text-secondary">{project.impact}</p>
                </div>
                
                {/* Tech Stack Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((t, i) => (
                    <span key={i} className="text-xs font-mono px-3 py-1 bg-white/5 border border-white/10 rounded-full text-gray-300">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
