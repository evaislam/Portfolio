import { motion } from 'motion/react';
import { ArrowRight, Download, Terminal, Database, Bot } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen relative flex items-center justify-center pt-32 pb-16 px-4 md:px-8 overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 z-0 pointer-events-none" 
        style={{ 
          backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.1) 1.5px, transparent 1.5px)', 
          backgroundSize: '48px 48px',
          backgroundPosition: '0 0',
          maskImage: 'linear-gradient(to bottom, black 50%, transparent 100%)',
          WebkitMaskImage: 'linear-gradient(to bottom, black 50%, transparent 100%)'
        }}
      />
      
      {/* Abstract Glowing Orb */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-orange/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-[1440px] w-full mx-auto grid lg:grid-cols-2 gap-12 lg:gap-8 items-center relative z-10">
        
        {/* Left Column: Text Content */}
        <div className="flex flex-col items-start text-left space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel text-sm text-brand-orange font-medium"
          >
            <span className="w-2 h-2 rounded-full bg-brand-orange animate-pulse" />
            Available for work
          </motion.div>

          {/* Title Area */}
          <motion.div
             initial={{ opacity: 0, y: 30 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h1 className="text-6xl md:text-7xl lg:text-[100px] font-display font-bold leading-[0.9] tracking-tighter mb-4 text-glow flex whitespace-nowrap">
              {"EVA ISLAM".split('').map((char, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 50, filter: 'blur(10px)' }}
                  animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                  transition={{ duration: 0.8, delay: 0.2 + (index * 0.05), ease: [0.2, 0.65, 0.3, 0.9] }}
                  className={char === ' ' ? 'w-4 md:w-8' : 'inline-block hover:text-brand-orange transition-colors duration-300'}
                >
                  {char}
                </motion.span>
              ))}
            </h1>
            <div className="h-[1px] w-24 bg-white/20 mb-4" />
            <h2 className="text-xl md:text-2xl text-text-secondary font-display uppercase tracking-widest pl-1">
              Data & Analytics Engineer
            </h2>
          </motion.div>

          <motion.p
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.6, delay: 0.4 }}
             className="text-text-muted text-lg md:text-xl max-w-xl leading-relaxed"
          >
            Transforming Data Into Business Intelligence Through Analytics, Automation, and AI. Combining deep technical expertise with strategic product vision.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.6, delay: 0.6 }}
             className="flex flex-wrap items-center gap-4 pt-4"
          >
            <a href="#projects" className="group flex items-center gap-2 bg-brand-orange text-white px-8 py-4 rounded-full font-medium glow-orange-hover hover:scale-105 transition-all duration-300">
              View Projects
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="https://drive.google.com/uc?export=download&id=1-GT9z9Akpbr2colNdilLGpEqiW_zGuT3" 
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-8 py-4 rounded-full font-medium glass-panel glass-panel-hover text-white transition-all duration-300 hover:-translate-y-1"
            >
              <Download size={18} />
              Download Resume
            </a>
          </motion.div>
          
          {/* Metrics */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1 }}
            className="flex items-center gap-8 md:gap-12 pt-8 border-t border-white/10 mt-8 w-full"
          >
            <div>
              <p className="text-3xl font-display font-bold text-white mb-1">1.5+</p>
              <p className="text-xs text-text-muted uppercase tracking-wider">Years Exp.</p>
            </div>
            <div>
              <p className="text-3xl font-display font-bold text-white mb-1">15+</p>
              <p className="text-xs text-text-muted uppercase tracking-wider">Dashboards</p>
            </div>
            <div>
              <p className="text-3xl font-display font-bold text-white mb-1">10+</p>
              <p className="text-xs text-text-muted uppercase tracking-wider">Automations</p>
            </div>
          </motion.div>
        </div>

        {/* Right Column: Visuals & Tech Elements */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="relative lg:h-[700px] flex items-center justify-center lg:justify-end mt-12 lg:mt-0"
        >
          {/* Main Visual "Portrait" Placeholder (Cyberpunk/Abstract/Tech themed) */}
          <div className="relative w-full max-w-[500px] aspect-[4/5] overflow-hidden group">
             {/* Main portrait with simple fade and screen blend to seamlessly drop the pure black background */}
             <div 
               className="absolute inset-0 bg-[url('https://i.ibb.co/R4ggHNJY/Chat-GPT-Image-Jun-14-2026-11-23-24-AM.png')] bg-cover bg-center transition-all duration-700 opacity-90 group-hover:opacity-100 mix-blend-screen" 
             />
             
             {/* Subtle gradient to anchor the bottom */}
             <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-transparent to-transparent pointer-events-none" />
          </div>
        </motion.div>

      </div>

      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-xs text-text-muted uppercase tracking-widest">Scroll</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-white/30 to-transparent relative overflow-hidden">
          <motion.div 
            className="w-full h-1/2 bg-brand-orange"
            animate={{ top: ['-50%', '100%'] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
            style={{ position: 'absolute' }}
          />
        </div>
      </motion.div>
    </section>
  );
}
