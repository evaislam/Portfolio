import { motion } from 'motion/react';
import { Database } from 'lucide-react';

const TECH_STACK = [
  { name: 'Python', iconUrl: 'https://cdn.simpleicons.org/python/3776AB' },
  { name: 'SQL', iconUrl: 'lucide-database' },
  { name: 'Power BI', iconUrl: 'https://cdn.simpleicons.org/powerbi/F2C811' },
  { name: 'Tableau', iconUrl: 'https://cdn.simpleicons.org/tableau/E97627' },
  { name: 'Excel', iconUrl: 'https://cdn.simpleicons.org/microsoftexcel/217346' },
  { name: 'BigQuery', iconUrl: 'https://cdn.simpleicons.org/googlebigquery/669DF6' },
  { name: 'Looker', iconUrl: 'https://cdn.simpleicons.org/looker/4285F4' },
  { name: 'Metabase', iconUrl: 'https://cdn.simpleicons.org/metabase/509EE3' },
  { name: 'ChatGPT', iconUrl: 'https://cdn.simpleicons.org/openai/412991' },
  { name: 'Gemini AI', iconUrl: 'https://cdn.simpleicons.org/googlegemini/8E75B2' },
  { name: 'Claude', iconUrl: 'https://cdn.simpleicons.org/anthropic/FFFFFF' },
  { name: 'Cursor', iconUrl: 'https://avatars.githubusercontent.com/u/102510006?s=200&v=4' },
  { name: 'Zapier', iconUrl: 'https://cdn.simpleicons.org/zapier/FF4A00' },
  { name: 'Make', iconUrl: 'https://cdn.simpleicons.org/make/FFFFFF' },
  { name: 'n8n', iconUrl: 'https://cdn.simpleicons.org/n8n/EA4B71' },
];

export default function TechStack() {
  return (
    <section className="py-24 px-4 md:px-8 relative bg-brand-dark/30 border-y border-white/5 overflow-hidden">
        {/* Dynamic sweeping background */}
        <div className="absolute top-0 right-0 w-[40vw] h-full bg-gradient-to-l from-brand-orange/5 to-transparent blur-3xl" />
        
        <div className="max-w-[1440px] mx-auto relative z-10">
            <div className="flex flex-col items-center mb-16">
              <motion.h3 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-xl md:text-2xl font-display font-medium text-text-secondary uppercase tracking-[0.2em] mb-4 text-center"
              >
                Technologies I Configure
              </motion.h3>
              <div className="w-12 h-1 bg-brand-orange glow-orange" />
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-4">
                {TECH_STACK.map((tech, idx) => (
                    <motion.div
                      key={tech.name}
                      initial={{ opacity: 0, scale: 0.8, y: 20 }}
                      whileInView={{ opacity: 1, scale: 1, y: 0 }}
                      viewport={{ once: true, margin: "-50px" }}
                      transition={{ duration: 0.5, delay: idx * 0.1 }}
                      whileHover={{ scale: 1.1, zIndex: 10 }}
                      className="aspect-square glass-panel rounded-2xl flex flex-col items-center justify-center p-2 group cursor-default hover:border-brand-orange/50 hover:bg-brand-orange/10 transition-all duration-300 relative"
                    >
                      {/* Glow Behind */}
                      <div className="absolute inset-0 bg-brand-orange/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      
                      <motion.div 
                        animate={{ y: [0, -4, 0] }}
                        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: idx * 0.2 }}
                        className="w-10 h-10 mb-2 rounded-full bg-white/5 flex items-center justify-center text-xs font-mono text-text-muted group-hover:bg-brand-orange/20 transition-colors"
                      >
                        {tech.iconUrl === 'lucide-database' ? (
                          <Database size={24} className="text-[#4169E1]" />
                        ) : (
                          <img src={tech.iconUrl} alt={`${tech.name} logo`} className="w-6 h-6 object-contain drop-shadow-[0_0_8px_rgba(255,255,255,0.1)] group-hover:scale-110 transition-transform duration-300" />
                        )}
                      </motion.div>
                      <span className="text-[10px] sm:text-xs font-medium text-text-muted text-center leading-tight group-hover:text-white transition-colors">{tech.name}</span>
                    </motion.div>
                ))}
            </div>
        </div>
    </section>
  );
}
