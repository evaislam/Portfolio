import { motion } from 'motion/react';
import { Network, DatabaseZap, Workflow } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 px-4 md:px-8 relative">
      <div className="max-w-[1440px] mx-auto">
        <motion.div
           initial={{ opacity: 0, y: 30 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.8 }}
           className="mb-16 md:mb-24 flex flex-col md:flex-row gap-6 md:items-end justify-between"
        >
          <div>
            <p className="text-brand-orange uppercase tracking-widest text-sm font-semibold mb-3">01 // About Me</p>
            <h2 className="text-4xl md:text-5xl lg:text-7xl font-display font-bold tracking-tight">
              Bridging The Gap Between <br className="hidden md:block"/>
              <span className="text-text-muted">Data & Intelligence.</span>
            </h2>
          </div>
        </motion.div>

        <div className="flex flex-col gap-12">
          
          {/* Main Content */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="prose prose-invert prose-lg max-w-none text-text-secondary leading-relaxed"
          >
            <p className="text-xl text-white mb-8 border-l-2 border-brand-orange pl-6 py-2">
              I am a results-driven Data Analyst who transforms complex datasets into clear, actionable insights.
            </p>
            <p className="mb-0">
              By combining analytical thinking, data visualization, and business understanding, I help organizations uncover opportunities, optimize performance, and make confident, data-informed decisions.
            </p>
          </motion.div>

          {/* Cards grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
             <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="glass-panel p-6 rounded-2xl border-l-[3px] border-l-brand-orange glass-panel-hover"
             >
                <DatabaseZap className="text-brand-orange mb-4" size={28} />
                <h3 className="text-white font-display font-bold text-xl mb-2">Data Architecture</h3>
                <p className="text-sm text-text-muted">Designing scalable, secure, and robust data lakes and warehouses for modern applications.</p>
             </motion.div>

             <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="glass-panel p-6 rounded-2xl border-l-[3px] border-l-blue-500 glass-panel-hover"
             >
                <Network className="text-blue-500 mb-4" size={28} />
                <h3 className="text-white font-display font-bold text-xl mb-2">AI Integration</h3>
                <p className="text-sm text-text-muted">Orchestrating Gemini, Claude, and ChatGPT to build intelligent reasoning engines.</p>
             </motion.div>

             <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="glass-panel p-6 rounded-2xl border-l-[3px] border-l-green-500 glass-panel-hover"
             >
                <Workflow className="text-green-500 mb-4" size={28} />
                <h3 className="text-white font-display font-bold text-xl mb-2">Hyper-Automation</h3>
                <p className="text-sm text-text-muted">Unifying fragmented systems via Zapier, Make, and n8n to achieve optimal efficiency.</p>
             </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
