import { motion } from 'motion/react';

const SKILL_CATEGORIES = [
  {
    title: 'Analytics & Visualization',
    skills: [
      { name: 'Power BI', level: 95 },
      { name: 'Tableau', level: 90 },
      { name: 'Looker Studio', level: 85 },
      { name: 'Excel / Spreadsheets', level: 95 },
    ]
  },
  {
    title: 'Data & Cloud',
    skills: [
      { name: 'SQL', level: 90 },
      { name: 'Python', level: 85 },
      { name: 'BigQuery', level: 80 },
      { name: 'AWS Basics', level: 70 },
    ]
  },
  {
    title: 'Automation & AI',
    skills: [
      { name: 'Zapier & Make', level: 95 },
      { name: 'n8n', level: 85 },
      { name: 'ChatGPT / Gemini / Claude', level: 90 },
      { name: 'AI Agents Architecture', level: 80 },
    ]
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-24 px-4 md:px-8 relative bg-brand-dark/50">
      <div className="max-w-[1440px] mx-auto">
        <motion.div
           initial={{ opacity: 0, y: 30 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.8 }}
           className="mb-16"
        >
          <p className="text-brand-orange uppercase tracking-widest text-sm font-semibold mb-3">02 // Expertise</p>
          <h2 className="text-4xl md:text-5xl lg:text-7xl font-display font-bold tracking-tight">
            Technical Arsenal.
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SKILL_CATEGORIES.map((category, idx) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: idx * 0.2 }}
              className="glass-panel p-8 rounded-3xl"
            >
              <h3 className="text-2xl font-display font-bold text-white mb-8 border-b border-white/10 pb-4">
                {category.title}
              </h3>
              
              <div className="space-y-6">
                {category.skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-center mb-2">
                       <span className="text-sm font-medium text-text-secondary">{skill.name}</span>
                       <span className="text-xs font-mono text-brand-orange">{skill.level}%</span>
                    </div>
                    <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                       <motion.div 
                         initial={{ width: 0 }}
                         whileInView={{ width: `${skill.level}%` }}
                         viewport={{ once: true }}
                         transition={{ duration: 1.5, delay: 0.5 + idx * 0.2, ease: "easeOut" }}
                         className="h-full bg-gradient-to-r from-brand-orange/50 to-brand-orange rounded-full relative"
                       >
                         <div className="absolute right-0 top-0 bottom-0 w-4 bg-white/50 blur-[2px]" />
                       </motion.div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
