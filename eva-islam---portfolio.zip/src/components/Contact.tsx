import { useRef, useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { Mail, Github, Linkedin, FileText, Send, CheckCircle, AlertCircle } from 'lucide-react';
import emailjs from '@emailjs/browser';

export default function Contact() {
  const formRef = useRef<HTMLFormElement>(null);
  const [isSending, setIsSending] = useState(false);
  const [statusMessage, setStatusMessage] = useState({ text: '', type: '' });

  const sendEmail = (e: FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    setIsSending(true);
    setStatusMessage({ text: '', type: '' });

    emailjs.sendForm('service_2zknnmb', 'template_o3gb7ik', formRef.current, 'jPJASzWMADSRJRylL')
      .then(() => {
          setStatusMessage({ text: 'Message sent successfully!', type: 'success' });
          setIsSending(false);
          if (formRef.current) formRef.current.reset();
      }, () => {
          setStatusMessage({ text: 'Failed to send message. Please try again.', type: 'error' });
          setIsSending(false);
      });
  };

  return (
    <section id="contact" className="py-24 px-4 md:px-8 relative bg-brand-dark/50 overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-orange/5 blur-[120px] pointer-events-none rounded-full" />
      
      <div className="max-w-[1440px] mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          
           {/* Left Content */}
           <motion.div
             initial={{ opacity: 0, x: -30 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true, margin: "-100px" }}
             transition={{ duration: 0.8 }}
           >
              <p className="text-brand-orange uppercase tracking-widest text-sm font-semibold mb-3">07 // Get in Touch</p>
              <h2 className="text-5xl md:text-7xl font-display font-bold tracking-tight mb-8">
                Let's Build <br/> The Future.
              </h2>
              <p className="text-orange-300/90 text-[14px] font-serif mb-12 max-w-md" style={{ fontFamily: '"Times New Roman", Times, serif' }}>
                From raw data to strategic decisions — I build reliable analytics solutions that drive clarity, efficiency, and measurable results.
              </p>

              <div className="flex flex-col gap-6">
                <a href="mailto:evas70498@gmail.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 group w-fit">
                   <div className="w-14 h-14 rounded-full glass-panel flex items-center justify-center text-brand-orange transition-transform duration-300 group-hover:scale-110 group-hover:bg-brand-orange/10">
                     <Mail size={24} />
                   </div>
                   <div>
                     <p className="text-sm font-mono text-text-muted mb-1">Email</p>
                     <p className="text-lg font-medium text-white group-hover:text-brand-orange transition-colors underline decoration-white/30 group-hover:decoration-brand-orange underline-offset-4 cursor-pointer">evas70498@gmail.com</p>
                   </div>
                </a>
                
                <div className="flex gap-4 mt-4">
                  {[
                    { icon: Linkedin, href: "https://www.linkedin.com/in/evaislam70498", name: "LinkedIn" },
                    { icon: Github, href: "https://github.com/evaislam", name: "GitHub" }
                  ].map((social) => (
                    <a 
                      key={social.name}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 rounded-full glass-panel glass-panel-hover flex items-center gap-2 text-text-secondary hover:text-white transition-colors"
                    >
                      <social.icon size={18} />
                      <span className="text-sm font-medium">{social.name}</span>
                    </a>
                  ))}
                </div>
              </div>
           </motion.div>

           {/* Right Content Form */}
           <motion.form 
             ref={formRef}
             initial={{ opacity: 0, scale: 0.95 }}
             whileInView={{ opacity: 1, scale: 1 }}
             viewport={{ once: true, margin: "-100px" }}
             transition={{ duration: 0.8, delay: 0.2 }}
             className="glass-panel p-8 md:p-12 rounded-3xl relative"
             onSubmit={sendEmail}
           >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
                 <div>
                   <label className="block text-xs font-mono text-text-muted mb-2 uppercase tracking-wider">Name</label>
                   <input 
                     type="text" 
                     name="name"
                     required
                     className="w-full bg-brand-black/50 border border-white/10 rounded-xl px-4 py-4 text-white focus:outline-none focus:border-brand-orange focus:bg-brand-black transition-all"
                     placeholder="John Doe"
                   />
                 </div>
                 <div>
                   <label className="block text-xs font-mono text-text-muted mb-2 uppercase tracking-wider">Email</label>
                   <input 
                     type="email" 
                     name="email"
                     required
                     className="w-full bg-brand-black/50 border border-white/10 rounded-xl px-4 py-4 text-white focus:outline-none focus:border-brand-orange focus:bg-brand-black transition-all"
                     placeholder="john@example.com"
                   />
                 </div>
              </div>
              <div className="mb-6">
                 <label className="block text-xs font-mono text-text-muted mb-2 uppercase tracking-wider">Company / Subject</label>
                 <input 
                   type="text" 
                   name="subject"
                   className="w-full bg-brand-black/50 border border-white/10 rounded-xl px-4 py-4 text-white focus:outline-none focus:border-brand-orange focus:bg-brand-black transition-all"
                   placeholder="Project Inquiry"
                 />
              </div>
              <div className="mb-8">
                 <label className="block text-xs font-mono text-text-muted mb-2 uppercase tracking-wider">Message</label>
                 <textarea 
                   rows={5}
                   name="message"
                   required
                   className="w-full bg-brand-black/50 border border-white/10 rounded-xl px-4 py-4 text-white focus:outline-none focus:border-brand-orange focus:bg-brand-black transition-all resize-none"
                   placeholder="Tell me about your data challenges..."
                 ></textarea>
              </div>
              
              <button 
                type="submit"
                disabled={isSending}
                className="w-full py-4 rounded-xl bg-brand-orange text-white font-medium flex items-center justify-center gap-2 hover:bg-brand-orange/90 transition-colors glow-orange-hover disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isSending ? 'Sending...' : 'Send Message'} {!isSending && <Send size={18} />}
              </button>

              {statusMessage.text && (
                <div className={`mt-4 p-4 rounded-xl flex items-center gap-3 text-sm font-medium ${
                  statusMessage.type === 'success' ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                }`}>
                  {statusMessage.type === 'success' ? <CheckCircle size={18} /> : <AlertCircle size={18} />}
                  {statusMessage.text}
                </div>
              )}
           </motion.form>

        </div>
      </div>
    </section>
  );
}
