import { motion } from 'motion/react';
import { Briefcase } from 'lucide-react';

const EXPERIENCES = [
  {
    id: 1,
    role: "Executive Data & Analytics Engineer",
    company: "PATHAO",
    period: "2025 - Present",
    description: "Designing end-to-end data pipelines, developing interactive Power BI/Tableau dashboards, and engineering custom AI automation agents for diverse business clients.",
    achievements: [
      "Built 15+ complex business intelligence dashboards.",
      "reduced reporting time by 80% through automated cloud workflows.",
      "Implemented LLM-based systems for automated document parsing."
    ]
  },
  {
    id: 3,
    role: "Intern",
    company: "PATHAO",
    period: "Nov 2024 - Feb 2025",
    description: "Assisted senior analysts in querying large datasets, cleaning anomalous data, and creating daily operational reports in Excel and SQL.",
    achievements: [
      "Streamlined data cleaning processes using Python scripts.",
      "Designed foundational ETL workflows later adopted by the broader team.",
      "Presented weekly data insights to departmental stakeholders."
    ]
  }
];

export default function Experience() {
  return (
    <section id="experience" className="py-24 px-4 md:px-8 relative">
      <div className="max-w-[1440px] mx-auto">
        <motion.div
           initial={{ opacity: 0, y: 30 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true, margin: "-100px" }}
           transition={{ duration: 0.8 }}
           className="mb-16 md:mb-24"
        >
          <p className="text-brand-orange uppercase tracking-widest text-sm font-semibold mb-3">03 // Timeline</p>
          <h2 className="text-4xl md:text-5xl lg:text-7xl font-display font-bold tracking-tight">
            Professional Experience.
          </h2>
        </motion.div>

        <div className="relative border-l border-white/10 ml-4 md:ml-8 space-y-16">
          {EXPERIENCES.map((exp, idx) => (
            <motion.div 
              key={exp.id}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="relative pl-8 md:pl-12"
            >
              {/* Timeline dot */}
              <div className="absolute w-4 h-4 rounded-full bg-brand-orange left-[-8.5px] top-1.5 glow-orange" />
              {/* Timeline connecting line segment (glow effect on active) */}
              <div className="absolute w-px h-full bg-gradient-to-b from-brand-orange/50 to-transparent left-[-0.5px] top-6" />

              <div className="glass-panel p-6 md:p-8 rounded-3xl glass-panel-hover group relative overflow-hidden">
                 {/* Background subtle gradient for card */}
                 <div className="absolute inset-0 bg-gradient-to-br from-brand-orange/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                 
                 <div className="relative z-10">
                   <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-4">
                     <div>
                       <h3 className="text-2xl font-display font-bold text-white tracking-tight">{exp.role}</h3>
                       <p className="text-brand-orange font-medium flex items-center gap-2 mt-1">
                         <Briefcase size={16} /> 
                         {exp.company}
                       </p>
                     </div>
                     <span className="px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm font-mono text-text-secondary whitespace-nowrap inline-block w-fit">
                        {exp.period}
                     </span>
                   </div>

                   <p className="text-text-secondary mb-6 leading-relaxed">
                     {exp.description}
                   </p>

                   <ul className="space-y-3">
                     {exp.achievements.map((achievement, i) => (
                       <li key={i} className="flex items-start gap-3">
                         <span className="text-brand-orange mt-1">✓</span>
                         <span className="text-text-muted text-sm leading-relaxed">{achievement}</span>
                       </li>
                     ))}
                   </ul>
                 </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
