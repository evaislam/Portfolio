fetch("https://ibb.co.com/k6GGcJP5").then(r=>r.text()).then(t => {
  const matches = t.match(/https?:[^"]+\.(png|jpg|jpeg|webp)/gi);
  if (matches) console.log(matches.join('\n'));
});
